import UIKit
import Foundation

// https://hasancanakgunduz.medium.com/type-erasure-in-swift-5086f764b33e

protocol BusinessRule {
    associatedtype Model
    func doBusiness(with model: Model)
}

struct BusinessModel1 {
    
}

struct AnyBusinessRule<T>: BusinessRule {
    
    typealias Model = T
    
    private let doBusinessClosure: (T) -> Void
    
    init<U: BusinessRule>(businessRule: U) where U.Model == T {
        doBusinessClosure = businessRule.doBusiness
    }
    
    func doBusiness(with model: T) {
        doBusinessClosure(model)
    }
}

struct BusinessManager {
    let rule: AnyBusinessRule<BusinessModel1>
}

struct BusinessRule1: BusinessRule {
    func doBusiness(with model: BusinessModel1) {
        print("I am doing business rule 1")
    }
}

struct BusinessRule2: BusinessRule {
    func doBusiness(with model: BusinessModel1) {
        print("I am doing business rule 2")
    }
}

var manager = BusinessManager(rule: AnyBusinessRule(businessRule: BusinessRule1()))
manager.rule.doBusiness(with: BusinessModel1()) // I am doing business rule 1
manager = BusinessManager(rule: AnyBusinessRule(businessRule: BusinessRule2()))
manager.rule.doBusiness(with: BusinessModel1()) // I am doing business rule 2
